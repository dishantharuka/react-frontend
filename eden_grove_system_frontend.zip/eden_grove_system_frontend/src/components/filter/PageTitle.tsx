export function PageTitle(props: { title: string }) {
    return (
        <h1 style={{ marginBottom: '20px' }}>{props.title}</h1>
    );
}