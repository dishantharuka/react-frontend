export class FieldDashboard {
    constructor(
        public fCode: string,
        public fieldName: string,
        public fieldSize: number,
        public staffList: number,
        public cropList: number,
        public fieldImage1: string,
    ) {
    }
}