export class ChartData {
    constructor(
        public fieldName: string,
        public logCount: number,
    ) {
    }
}